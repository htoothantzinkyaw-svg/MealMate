package com.example.mealmate_ht;


import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.github.clans.fab.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.Nullable;

public class ShoppingFragment extends Fragment {

    private FirebaseDatabase database;
    private ArrayList<Map<String, Object>> savedItem = new ArrayList<>();
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private FloatingActionButton addBottom, shareBottom;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = FirebaseDatabase.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_shopping, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new ItemAdapter(getContext(), savedItem);
        recyclerView.setAdapter(adapter);

        // Add swipe functionality for RecyclerView
        ItemTouchHelper touchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                String itemName = savedItem.get(position).get("name").toString();

                if (direction == ItemTouchHelper.LEFT) {
                    removeFromList(itemName);
                    savedItem.remove(position);
                    adapter.notifyItemRemoved(position);
                    Toast.makeText(getContext(), "Deleted: " + itemName, Toast.LENGTH_SHORT).show();
                } else if (direction == ItemTouchHelper.RIGHT) {
                    markAsPurchased(itemName);
                    Toast.makeText(getContext(), "Marked as purchased: " + itemName, Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView,
                                    @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY,
                                    int actionState, boolean isCurrentlyActive) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    View itemView = viewHolder.itemView;
                    Paint paint = new Paint();
                    Paint textPaint = new Paint();
                    textPaint.setColor(Color.WHITE); // Text color
                    textPaint.setTextSize(60); // Text size
                    textPaint.setTextAlign(Paint.Align.CENTER); // Center-align text

                    if (dX > 0) {
                        // Swipe Right - Mark as Purchased
                        paint.setColor(getResources().getColor(R.color.black));
                        c.drawRect((float) itemView.getLeft(), (float) itemView.getTop(),
                                dX, (float) itemView.getBottom(), paint);

                        // Draw the "Mark as Purchased" text
                        c.drawText("Mark as Purchased",
                                (float) itemView.getLeft() + dX / 2, // Center text in swipe area
                                (float) itemView.getTop() + (float) itemView.getHeight() / 2, // Vertically centered
                                textPaint);
                    } else if (dX < 0){
                        // Swipe Left - Delete
                        paint.setColor(getResources().getColor(R.color.red));
                        c.drawRect((float) itemView.getRight() + dX, (float) itemView.getTop(),
                                (float) itemView.getRight(), (float) itemView.getBottom(), paint);

                        // Draw the "Delete" text
                        c.drawText("Delete",
                                (float) itemView.getRight() + dX / 2, // Center text in swipe area
                                (float) itemView.getTop() + (float) itemView.getHeight() / 2, // Vertically centered
                                textPaint);
                    } else{
                        c.restore();
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        });


        touchHelper.attachToRecyclerView(recyclerView);

        // Load data from Firebase when the fragment is created
        loadItemsFromDatabase();

        // Add new item
        addBottom = view.findViewById(R.id.addButton);
        addBottom.setOnClickListener(v -> {
            // Handle adding new item
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            LayoutInflater inflaterDialog = requireActivity().getLayoutInflater();
            View dialogView = inflaterDialog.inflate(R.layout.add_items, null);
            builder.setView(dialogView);

            EditText editlistname = dialogView.findViewById(R.id.editlistname);
            Button saveButton = dialogView.findViewById(R.id.addlistbuttom);

            AlertDialog dialog = builder.create();

            saveButton.setOnClickListener(v1 -> {
                String name = editlistname.getText().toString();
                if (name.isEmpty()) {
                    Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    saveItemToDatabase(name);
                    dialog.dismiss();
                    loadItemsFromDatabase();  // Reload the data after adding a new item
                }
            });

            dialog.show();
        });

        shareBottom = view.findViewById(R.id.shareButton);
        shareBottom.setOnClickListener(v -> sendSMS());
    }

    private void loadItemsFromDatabase() {
        DatabaseReference itemRef = database.getReference("shopping_lists").child("items");

        itemRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                savedItem.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Map<String, Object> item = (Map<String, Object>) dataSnapshot.getValue();
                    savedItem.add(item);
                }
                adapter.notifyDataSetChanged();  // Notify adapter to refresh the RecyclerView
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ShoppingFragment", "Failed to read items from database", error.toException());
            }
        });
    }

    private void saveItemToDatabase(String name) {
        DatabaseReference itemRef = database.getReference("shopping_lists").child("items");

        String itemId = itemRef.push().getKey();
        if (itemId != null) {
            Map<String, Object> item = new HashMap<>();
            item.put("name", name);
            item.put("purchased", false);

            itemRef.child(itemId).setValue(item)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(getContext(), "Item added!", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void markAsPurchased(String name) {
        DatabaseReference itemRef = database.getReference("shopping_lists").child("items");

        itemRef.orderByChild("name").equalTo(name).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    itemSnapshot.getRef().child("purchased").setValue(true);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("Firestore", "Error getting documents: ", error.toException());
            }
        });
    }

    private void removeFromList(String name) {
        DatabaseReference itemRef = database.getReference("shopping_lists").child("items");

        itemRef.orderByChild("name").equalTo(name).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    itemSnapshot.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.w("Firestore", "Error getting documents: ", error.toException());
            }
        });
    }

    private void sendSMS() {
        androidx.appcompat.app.AlertDialog.Builder builder =new androidx.appcompat.app.AlertDialog.Builder(getContext());
        builder.setTitle("Enter Phone No");

        final EditText input =new EditText(getContext());
        builder.setView(input);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog,int which){
                String mobileNo =input.getText().toString();

                try {
                    Intent intent= new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("smsto:"+mobileNo));
                    String message="";
                    for(Map<String,Object>item:savedItem){
                        message +=item.get("name");
                        message +="\n";

                    }
                    intent.putExtra("sms_body",message);
                    startActivity(intent);

                }catch (ActivityNotFoundException exp){
                    Toast.makeText(getContext(),"No messaging app found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
}
