package com.example.mealmate_ht;

public class DataClass {
    private String mealTitle;
    private String mealIng;
    private String mealDesc;

    private String key;
    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getmealTitle() {
        return mealTitle;
    }
    public String getmealIng() {
        return mealIng;
    }
    public String getmealDesc() {
        return mealDesc;
    }

    public DataClass(String mealTitle, String mealIng, String mealDesc) {
        this.mealTitle = mealTitle;
        this.mealIng = mealIng;
        this.mealDesc = mealDesc;

    }
    public DataClass() {
        // This constructor is needed for Firebase to deserialize data
    }
}